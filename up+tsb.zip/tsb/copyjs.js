function selectionClear() {
let tsbText = document.getElementById("tsbT");
tsbText.focus();
tsbText.selectionEnd = 0;
}
function copy() {
let tsbText = document.getElementById("tsbT");
tsbText.removeAttribute("disabled");
tsbText.select();
document.execCommand('copy');
let tsbCopyResU = document.getElementById("resultCopy");
tsbCopyResU.childNodes[0].nodeValue = tsbText.value;
selectionClear();
tsbText.setAttribute("disabled", "true");
}
function cut() {
let tsbText = document.getElementById("tsbT");
tsbText.removeAttribute("disabled");
tsbText.select();
document.execCommand('cut');
let tsbCopyResU = document.getElementById("resultCopy");
tsbCopyResU.childNodes[0].nodeValue = tsbText.value;
selectionClear();
tsbText.setAttribute("disabled", "true");
}
function deleteText() {
let tsbText = document.getElementById("tsbT");
tsbText.removeAttribute("disabled");
tsbText.select();
document.execCommand('delete');
document.getElementById("resultCopy");
tsbCopyResU.childNodes[0].nodeValue = tsbText.value;
selectionClear();
tsbText.setAttribute("disabled", "true");
}
